from django.shortcuts import render
from . import forms
import pandas as pd
import numpy as np
import nltk
import re
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.stem import PorterStemmer,WordNetLemmatizer
nltk.download('wordnet')
import pickle
import joblib

# Create your views here.
def base(request):
    return render(request,"index/base.html")

def index(request):
    form = forms.testp()
    if request.method == "POST":
        form = forms.testp(request.POST)
        model = joblib.load("modelsvc.sav")
        tfi = pickle.load(open("tfidf.pkl","rb"))
        lemmi = WordNetLemmatizer()
        cv = TfidfVectorizer(lowercase=True,stop_words="english",vocabulary = tfi.vocabulary_)
        if form.is_valid():
            text = form.cleaned_data["text"]
            t = re.sub("[^a-zA-Z]"," ",str(text))
            t = t.lower()
            t = t.split()
            t = [lemmi.lemmatize(word) for word in t]
            text=' '.join(t)
            X = (cv.fit_transform([text])).toarray()
            print(X.shape)
            pred = model.predict(X)
            print(pred)








            
            print(text)
    return render(request,"index/index.html",{"form":form})

def result(request):
    
    return render(request,"index/result.html")