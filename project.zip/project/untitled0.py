# -*- coding: utf-8 -*-
"""
Created on Tue Dec  7 20:17:14 2021

@author: saigu
"""

import requests
from bs4 import BeautifulSoup
import html5lib
import time
from datetime import datetime
import pandas as pd

date = datetime.now()
year = date.year
month = date.month

url = "https://economictimes.indiatimes.com"

req = requests.get(url)
content = req.content

data=[]

soup = BeautifulSoup(content,'html.parser')

print(data)

las = soup.find_all('a')
for i in las:
    if "tesla" in i.text.lower():
        print(i["href"][0])
        data.append(i.text)
print(las)

p=[1,2,3]
p1=[4,5,6]
a = zip(p,p1)

for i,j in a:
    print(i,j)




